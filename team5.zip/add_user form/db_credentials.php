<?php

define("DB_SERVER", "localhost");
define("DB_USER", "team5" );
define("DB_PWD", "steam5");
define("DB_NAME", "team5");

?>