<?php

require_once('database.php');
require_once('queries2.php');

$db = dbConnect();

?>