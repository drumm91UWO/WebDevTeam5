<?php

include_once('../Database_files/initialize.php');

deactivate_all_activated_questions();
header("Location: instructorhome.php");


?>