<?php

require_once('database.php');
require_once('queries.php');


$db = dbConnect();

?>